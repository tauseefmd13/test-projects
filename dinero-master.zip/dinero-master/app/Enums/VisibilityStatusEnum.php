<?php

namespace App\Enums;

enum VisibilityStatusEnum: string
{
    case ACTIVE = 'active';
    case INACTIVE = 'inactive';
}